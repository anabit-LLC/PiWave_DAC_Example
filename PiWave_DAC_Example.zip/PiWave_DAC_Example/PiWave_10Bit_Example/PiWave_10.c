// ** PiWave_10 - 10-bit DAC Waveform Generator using PIO and DMA
//
// This application:
//   1) Builds a wavetable in RAM (wave_buff[]) using Waveforms.c/.h
//   2) Configures a PIO state machine to output 10-bit parallel DAC codes
//   3) Uses two chained DMA channels to continuously stream wave_buff[] into the PIO TX FIFO
//
// Wavetable format (same as Waveforms library):
//   - Each uint32_t word contains THREE 10-bit samples:
//       bits [ 9: 0]  sample0
//       bits [19:10]  sample1
//       bits [29:20]  sample2
//       bits [31:30]  unused (0)
//
// The PIO program (PiWave_10.pio) pulls 32-bit words and emit the
// samples at a rate controlled by the PIO clock divider and program structure.
//
#include <stdio.h>
#include <math.h>

#include "pico/stdlib.h"
#include "hardware/dma.h"
#include "hardware/pio.h"
#include "hardware/clocks.h"
#include "hardware/structs/pio.h"
#include "hardware/structs/dma.h"

#include "PiWave_10.pio.h"
#include "Waveforms.h"  

#define CLOCK_GPIO     21          //Pin to output system clock to DAC clock input
#define ARRAY_SIZE     256         //Waveform buffer size in 32-bit words
#define MAX_10BIT      1023        //10-bit max value for DAC
#define Z_CTRL_PIN     22          //Pin controlling output impedance switch, high 50 ohm and low high-Z
#define TERM_50_OHM 1
#define TERM_1_MOHM 0
/* Waveform selection */
#define SINE_WAVE      0
#define TRIANGLE_WAVE  1
#define SQUARE_WAVE    2
#define DC_SIGNAL      3
#define TWO_TONE       4

/*
  Global DMA waveform buffer.
  You aligned it to 1024 bytes, which pairs nicely with a 2^10 ring size
  (useful if you enable DMA ring wrapping over the whole buffer).
*/
static uint32_t wave_buff[ARRAY_SIZE] __attribute__((aligned(1024)));

/* Optional amplitude scaling for sine */
static uint16_t code_min = 0;
static uint16_t code_max = MAX_10BIT;

int main(void) {
    /* Initialize stdio (UART/USB depending on your Pico SDK config) */
    stdio_init_all();

    /* ----------------------------------------------------------------------
       GPIO: Output impedance control
       ---------------------------------------------------------------------- */
    gpio_init(Z_CTRL_PIN);
    gpio_set_dir(Z_CTRL_PIN, GPIO_OUT);

    //set to 1 for 50 ohm output, set to 0 for high-Z output
    gpio_put(Z_CTRL_PIN, TERM_50_OHM);

    /* ----------------------------------------------------------------------
       PIO output bus configuration
       ---------------------------------------------------------------------- */
    uint OUT_PIN_NUMBER = 6;        // Start GPIO for 10-bit DAC data output
    uint8_t NPINS = 10;             // 10 pins for 10-bit parallel output 
    float SM_CLK_FREQ = 150000000;  // State machine clock target (Hz), clock that goes to DAC

    // Select which waveform to generate
    uint8_t waveType = SINE_WAVE;

    // Output system clock on CLOCK_GPIO (for DAC clocking) 
    clock_gpio_init(CLOCK_GPIO,
                    CLOCKS_CLK_GPOUT0_CTRL_AUXSRC_VALUE_CLK_SYS,
                    1.0f);

    /* ----------------------------------------------------------------------
       Build the wavetable using Waveforms library
       ---------------------------------------------------------------------- */
    switch (waveType) {
        case SINE_WAVE:
            //third argument is number of cycles in the buffer, higher the number the higher the frequency
            DAC_10bit_packed_sine(wave_buff, ARRAY_SIZE, 16.0f, code_min, code_max);
            break;

        case TRIANGLE_WAVE:
            //third argument is number of cycles in the buffer, higher the number the higher the frequency
            DAC_10bit_packed_triangle(wave_buff, ARRAY_SIZE, 16.0f);
            break;

        case SQUARE_WAVE:
            //third argument is number of points each level of square wave is held, the higher the number the lower the frequency
            DAC_10bit_grouped_square(wave_buff, ARRAY_SIZE, 8);
            break;

        case DC_SIGNAL:
            //outputs continuous DC value, third argument is the DC code (0-1023)
            DAC_10bit_packed_dc(wave_buff, ARRAY_SIZE, 800);
            break;

        case TWO_TONE:
            //third argument is base cycles in the buffer, fourth argument is spacing cycles between the two tones
            DAC_10bit_packed_two_tone(wave_buff, ARRAY_SIZE, 16.0f, 3.0f);
            break;

        default:
            // Safe fallback, invalid waveType output sine wave
            DAC_10bit_packed_sine(wave_buff, ARRAY_SIZE, 16.0f, code_min, code_max);
            break;
    }

    /* ----------------------------------------------------------------------
       Initialize PIO (load program, claim SM, init pins/clocking)
       ---------------------------------------------------------------------- */
    PIO pio = pio0;
    uint sm = pio_claim_unused_sm(pio, true);

    /* Load the PIO program and initialize the chosen state machine */
    uint offset = pio_add_program(pio, &pio_byte_out_program);
    pio_byte_out_program_init(pio, sm, offset, OUT_PIN_NUMBER, NPINS, SM_CLK_FREQ);

    /* ----------------------------------------------------------------------
       DMA setup: two channels chained for continuous playback (ping-pong loop)
       ---------------------------------------------------------------------- */
    int dma_chan_a = dma_claim_unused_channel(true);
    int dma_chan_b = dma_claim_unused_channel(true);

    /* DMA Channel A configuration */
    dma_channel_config cfg_a = dma_channel_get_default_config(dma_chan_a);
    channel_config_set_transfer_data_size(&cfg_a, DMA_SIZE_32);    /* 32-bit words */
    channel_config_set_read_increment(&cfg_a, true);               /* walk wave_buff */
    channel_config_set_write_increment(&cfg_a, false);             /* fixed FIFO addr */
    channel_config_set_chain_to(&cfg_a, dma_chan_b);               /* A -> B */
    channel_config_set_dreq(&cfg_a, DREQ_PIO0_TX0);                /* paced by PIO TX */

    /*
      Ring wrap:
        write=false -> apply ring to READ address
        size_bits=10 -> 2^10 = 1024 bytes wrap
      Because wave_buff is 256 words * 4 bytes = 1024 bytes, this wraps exactly
      over the full buffer *if* the DMA transfer count runs long enough.
      (In your case, you still use a fixed transfer count and chaining, which is fine.)
    */
    channel_config_set_ring(&cfg_a, false, 10);

    /* DMA Channel B configuration (mirrors A, but chains back to A) */
    dma_channel_config cfg_b = dma_channel_get_default_config(dma_chan_b);
    channel_config_set_transfer_data_size(&cfg_b, DMA_SIZE_32);
    channel_config_set_read_increment(&cfg_b, true);
    channel_config_set_write_increment(&cfg_b, false);
    channel_config_set_chain_to(&cfg_b, dma_chan_a);               /* B -> A */
    channel_config_set_dreq(&cfg_b, DREQ_PIO0_TX0);
    channel_config_set_ring(&cfg_b, false, 10);

    /* Program DMA channel A */
    dma_channel_configure(
        dma_chan_a,
        &cfg_a,
        &pio0_hw->txf[sm],   /* destination: PIO TX FIFO for this SM */
        wave_buff,            /* source: wavetable buffer */
        ARRAY_SIZE,          /* transfer ARRAY_SIZE 32-bit words */
        false                /* don't start yet */
    );

    /* Program DMA channel B (same transfer) */
    dma_channel_configure(
        dma_chan_b,
        &cfg_b,
        &pio0_hw->txf[sm],
        wave_buff,
        ARRAY_SIZE,
        false
    );

    /* Start channel A; it will chain to B, then back to A forever */
    dma_start_channel_mask(1u << dma_chan_a);

    /* Idle forever; PIO+DMA keep running */
    while (1) {
        sleep_ms(1000);
    }

    return 0;
}
