#ifndef WAVEFORMS_H
#define WAVEFORMS_H

/*
    Waveforms.h  —  10-bit wavetable generators for PiWave_10 (RP2350/RP2040 + PIO + DMA)

    These functions generate common DAC waveforms into a uint32_t buffer that is
    streamed by DMA into a PIO TX FIFO.

    PACKING FORMAT (10-bit DAC, 3 samples per 32-bit word):
      - bits [ 9: 0]  = sample 0 (10 bits)
      - bits [19:10]  = sample 1 (10 bits)
      - bits [29:20]  = sample 2 (10 bits)
      - bits [31:30]  = unused (0)

    This matches your existing design: ARRAY_SIZE words => ARRAY_SIZE*3 samples total.

    NOTES:
      - All waveforms are generated as *codes* for a 10-bit DAC (0..1023).
      - Sine wave supports amplitude scaling using code_min/code_max.
      - Triangle and two-tone are full-scale by default (0..1023) unless scaled.
      - The functions do not perform any hardware I/O; they only fill memory buffers.
*/

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* ------------------------------ Constants ------------------------------ */

#define DAC_BITS_10          (10u)
#define DAC_MAX_10BIT        (1023u)      /* 2^10 - 1 */
#define DAC_MASK_10BIT       (0x03FFu)    /* mask for 10 bits */

/*
  Utility macro: pack three 10-bit samples into one 32-bit word.
  Upper two bits are left as 0.
*/
#define DAC_PACK3_10BIT(a, b, c) \
    ( ((uint32_t)((a) & DAC_MASK_10BIT) <<  0) | \
      ((uint32_t)((b) & DAC_MASK_10BIT) << 10) | \
      ((uint32_t)((c) & DAC_MASK_10BIT) << 20) )

/* --------------------------- Waveform APIs ---------------------------- */

/**
 * @brief Fill buffer with a scaled sine wave (3 samples packed per uint32_t).
 *
 * @param[out] out_array   Buffer of uint32_t words to fill.
 * @param[in]  array_words Number of 32-bit words in out_array.
 * @param[in]  num_cycles  Number of sine cycles across the entire buffer.
 * @param[in]  code_min    Minimum DAC code (clamped to 0..1023).
 * @param[in]  code_max    Maximum DAC code (clamped to 0..1023).
 */
void DAC_10bit_packed_sine(uint32_t *out_array,
                            int array_words,
                            float num_cycles,
                            uint16_t code_min,
                            uint16_t code_max);

/**
 * @brief Fill buffer with a full-scale triangle wave (0..1023).
 *
 * @param[out] out_array   Buffer of uint32_t words to fill.
 * @param[in]  array_words Number of 32-bit words in out_array.
 * @param[in]  num_cycles  Number of triangle cycles across the entire buffer.
 */
void DAC_10bit_packed_triangle(uint32_t *out_array,
                                int array_words,
                                float num_cycles);

/**
 * @brief Fill buffer with a grouped square wave (0 and 1023).
 *
 * Each level is held for group_size samples, then toggles. This is a "sample-based"
 * grouping (not word-based). With 3 samples/word, grouping naturally crosses word
 * boundaries.
 *
 * @param[out] out_array        Buffer of uint32_t words to fill.
 * @param[in]  array_words      Number of 32-bit words in out_array.
 * @param[in]  group_size_samps Number of consecutive samples per level (>=1).
 */
void DAC_10bit_grouped_square(uint32_t *out_array,
                               int array_words,
                               int group_size_samps);

/**
 * @brief Fill buffer with a constant DC code (same value repeated).
 *
 * @param[out] out_array   Buffer of uint32_t words to fill.
 * @param[in]  array_words Number of 32-bit words in out_array.
 * @param[in]  dc_value    DC code (only lower 10 bits used).
 */
void DAC_10bit_packed_dc(uint32_t *out_array,
                          int array_words,
                          uint16_t dc_value);

/**
 * @brief Fill buffer with a two-tone waveform (sum of two sines), full-scale 0..1023.
 *
 * Tone1 has base_cycles cycles across the buffer.
 * Tone2 has (base_cycles + spacing_cycles) cycles across the buffer.
 *
 * @param[out] out_array      Buffer of uint32_t words to fill.
 * @param[in]  array_words    Number of 32-bit words in out_array.
 * @param[in]  base_cycles    Cycles across buffer for tone 1.
 * @param[in]  spacing_cycles Additional cycles across buffer for tone 2.
 */
void DAC_10bit_packed_two_tone(uint32_t *out_array,
                                int array_words,
                                float base_cycles,
                                float spacing_cycles);

#ifdef __cplusplus
}
#endif

#endif /* WAVEFORMS_H */