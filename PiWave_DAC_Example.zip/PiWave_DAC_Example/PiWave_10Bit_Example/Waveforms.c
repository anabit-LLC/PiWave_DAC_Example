#include "Waveforms.h"
#include <math.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

/*
    Waveforms.c  —  10-bit wavetable generators (3 packed samples per 32-bit word)

    Implementation details:
      - total_samples = array_words * 3 (because 3 samples per word)
      - For each word i:
          sample indices: s0 = 3*i + 0, s1 = 3*i + 1, s2 = 3*i + 2
      - Each generated sample is clamped/masked to 10 bits and then packed.

    Important practical note for use:
      If num_cycles is an integer, the waveform will wrap seamlessly when the DMA
      loops back to the start of the buffer. Non-integer cycles will cause a
      discontinuity at wrap (which can add spurs/energy in the spectrum).
*/

/* ------------------------- Internal helpers -------------------------- */

/**
 * @brief Clamp [code_min, code_max] to valid 10-bit range and ensure min<=max.
 */
static inline void clamp_code_minmax_10(uint16_t *code_min, uint16_t *code_max)
{
    if (*code_min > DAC_MAX_10BIT) *code_min = DAC_MAX_10BIT;
    if (*code_max > DAC_MAX_10BIT) *code_max = DAC_MAX_10BIT;

    if (*code_max < *code_min) {
        uint16_t t = *code_min;
        *code_min = *code_max;
        *code_max = t;
    }
}

/**
 * @brief Generate one sample of a two-tone waveform at sample index n.
 *
 * This returns a 10-bit code in [0..1023] representing:
 *   s = 0.5*(sin(2π*c1*n/N) + sin(2π*c2*n/N))     -> [-1, +1]
 *   v = 0.5*s + 0.5                              -> [ 0,  1]
 *   code = v*1023
 *
 * The 0.5 factor on the sine sum keeps the combined waveform bounded.
 */
static inline uint16_t two_tone_sample_10(float n,
                                          float total_samples,
                                          float cycles1,
                                          float cycles2)
{
    const float a1 = 2.0f * (float)M_PI * cycles1 * n / total_samples;
    const float a2 = 2.0f * (float)M_PI * cycles2 * n / total_samples;

    /* Sum and scale to keep amplitude within [-1, +1] */
    const float s = 0.5f * (sinf(a1) + sinf(a2));   /* [-1, +1] */

    /* Map [-1, +1] -> [0, 1] */
    const float v = 0.5f * s + 0.5f;

    /* Convert to 10-bit code with rounding */
    uint16_t code = (uint16_t)(v * (float)DAC_MAX_10BIT + 0.5f);
    return (uint16_t)(code & DAC_MASK_10BIT);
}

/* ------------------------- Public functions -------------------------- */

void DAC_10bit_packed_sine(uint32_t *out_array,
                            int array_words,
                            float num_cycles,
                            uint16_t code_min,
                            uint16_t code_max)
{
    /*
      total_samples is the length of the wavetable in samples, not words.
      Because we pack 3 samples per word:
        total_samples = array_words * 3
    */
    const int samples_per_word = 3;
    const int total_samples = array_words * samples_per_word;

    /* Sanitize the amplitude range */
    clamp_code_minmax_10(&code_min, &code_max);
    const float span = (float)(code_max - code_min);

    for (int i = 0; i < array_words; ++i) {
        const int s0 = i * samples_per_word + 0;
        const int s1 = i * samples_per_word + 1;
        const int s2 = i * samples_per_word + 2;

        /*
          Compute sin() at each sample index. Angle is:
            angle = 2π * cycles * (sample_index / total_samples)
        */
        const float a0 = 2.0f * (float)M_PI * num_cycles * (float)s0 / (float)total_samples;
        const float a1 = 2.0f * (float)M_PI * num_cycles * (float)s1 / (float)total_samples;
        const float a2 = 2.0f * (float)M_PI * num_cycles * (float)s2 / (float)total_samples;

        /* Raw sine in [-1, +1] */
        const float s0f = sinf(a0);
        const float s1f = sinf(a1);
        const float s2f = sinf(a2);

        /* Normalize [-1, +1] -> [0, 1] */
        const float n0 = 0.5f * (s0f + 1.0f);
        const float n1 = 0.5f * (s1f + 1.0f);
        const float n2 = 0.5f * (s2f + 1.0f);

        /* Scale [0,1] into [code_min, code_max] and round */
        const uint16_t v0 = (uint16_t)(code_min + n0 * span + 0.5f);
        const uint16_t v1 = (uint16_t)(code_min + n1 * span + 0.5f);
        const uint16_t v2 = (uint16_t)(code_min + n2 * span + 0.5f);

        /* Pack three 10-bit samples into one 32-bit word */
        out_array[i] = DAC_PACK3_10BIT(v0, v1, v2);
    }
}

void DAC_10bit_grouped_square(uint32_t *out_array,
                               int array_words,
                               int group_size_samps)
{
    /*
      group_size_samps controls how many *samples* each level is held.
      Example: group_size_samps=8 -> high for 8 samples, low for 8 samples, repeat.
    */
    if (group_size_samps <= 0) group_size_samps = 1;

    const int samples_per_word = 3;

    /* Define the two levels */
    const uint16_t high_value = (uint16_t)DAC_MAX_10BIT;
    const uint16_t low_value  = 0;

    uint16_t current = high_value;
    int counter = 0;

    for (int i = 0; i < array_words; ++i) {
        /* Emit 3 samples per word, updating (current, counter) each time */
        uint16_t v0 = current;
        counter++;
        if (counter >= group_size_samps) {
            counter = 0;
            current = (current == low_value) ? high_value : low_value;
        }

        uint16_t v1 = current;
        counter++;
        if (counter >= group_size_samps) {
            counter = 0;
            current = (current == low_value) ? high_value : low_value;
        }

        uint16_t v2 = current;
        counter++;
        if (counter >= group_size_samps) {
            counter = 0;
            current = (current == low_value) ? high_value : low_value;
        }

        out_array[i] = DAC_PACK3_10BIT(v0, v1, v2);
    }
}

void DAC_10bit_packed_triangle(uint32_t *out_array,
                                int array_words,
                                float num_cycles)
{
    const int samples_per_word = 3;
    const int total_samples = array_words * samples_per_word;

    for (int i = 0; i < array_words; ++i) {
        const int s0 = i * samples_per_word + 0;
        const int s1 = i * samples_per_word + 1;
        const int s2 = i * samples_per_word + 2;

        /*
          Phase is the fractional part of cycles elapsed:
            phase = frac(num_cycles * sample_index / total_samples)
          fmodf(x, 1.0) is a common way to compute that fractional phase.
        */
        const float p0 = fmodf(num_cycles * (float)s0 / (float)total_samples, 1.0f);
        const float p1 = fmodf(num_cycles * (float)s1 / (float)total_samples, 1.0f);
        const float p2 = fmodf(num_cycles * (float)s2 / (float)total_samples, 1.0f);

        /*
          Triangle mapping:
            p in [0,0.5)  -> rising ramp 0..1
            p in [0.5,1)  -> falling ramp 1..0
        */
        const float t0 = (p0 < 0.5f) ? (2.0f * p0) : (2.0f * (1.0f - p0));
        const float t1 = (p1 < 0.5f) ? (2.0f * p1) : (2.0f * (1.0f - p1));
        const float t2 = (p2 < 0.5f) ? (2.0f * p2) : (2.0f * (1.0f - p2));

        /* Scale [0,1] -> [0,1023] with rounding */
        const uint16_t v0 = (uint16_t)(t0 * (float)DAC_MAX_10BIT + 0.5f);
        const uint16_t v1 = (uint16_t)(t1 * (float)DAC_MAX_10BIT + 0.5f);
        const uint16_t v2 = (uint16_t)(t2 * (float)DAC_MAX_10BIT + 0.5f);

        out_array[i] = DAC_PACK3_10BIT(v0, v1, v2);
    }
}

void DAC_10bit_packed_dc(uint32_t *out_array,
                          int array_words,
                          uint16_t dc_value)
{
    /* Only keep the lower 10 bits */
    const uint16_t v = (uint16_t)(dc_value & DAC_MASK_10BIT);

    /* Pack once, then replicate into the whole buffer */
    const uint32_t packed = DAC_PACK3_10BIT(v, v, v);

    for (int i = 0; i < array_words; ++i) {
        out_array[i] = packed;
    }
}

void DAC_10bit_packed_two_tone(uint32_t *out_array,
                                int array_words,
                                float base_cycles,
                                float spacing_cycles)
{
    const int samples_per_word = 3;
    const int total_samples_i = array_words * samples_per_word;
    const float total_samples = (float)total_samples_i;

    const float cycles1 = base_cycles;
    const float cycles2 = base_cycles + spacing_cycles;

    for (int i = 0; i < array_words; ++i) {
        const int s0 = i * samples_per_word + 0;
        const int s1 = i * samples_per_word + 1;
        const int s2 = i * samples_per_word + 2;

        const uint16_t v0 = two_tone_sample_10((float)s0, total_samples, cycles1, cycles2);
        const uint16_t v1 = two_tone_sample_10((float)s1, total_samples, cycles1, cycles2);
        const uint16_t v2 = two_tone_sample_10((float)s2, total_samples, cycles1, cycles2);

        out_array[i] = DAC_PACK3_10BIT(v0, v1, v2);
    }
}
