#include "Waveforms.h"
#include <math.h>
#include <stdlib.h>

/*
    This file contains helper routines that generate common waveforms
    (sine, triangle, square, DC, two-tone) for a 14-bit DAC.

    IMPORTANT PACKING FORMAT (used by all "packed" functions below):
      - Each uint32_t word contains TWO 14-bit DAC samples.
      - Sample 0 is stored in bits [13:0]
      - Sample 1 is stored in bits [23:14]
      - Bits [31:24] are unused (kept as 0)

    This format is convenient when the hardware interface (PIO/SPI/DMA) streams
    32-bit words but the DAC itself consumes 14-bit codes.

    Assumed macros from Waveforms.h:
      - DAC_MAX_14BIT  : 16383 for a 14-bit full-scale code (2^14 - 1)
      - DAC_MASK_14BIT : 0x3FFF to keep only the lower 14 bits
*/

/**
 * @brief Clamp and sanitize a [code_min, code_max] range for a 14-bit DAC.
 *
 * Many waveform functions accept a min/max code range to scale the waveform.
 * This helper makes sure:
 *  - both ends are limited to the valid 14-bit range [0..DAC_MAX_14BIT]
 *  - if the user accidentally passes code_min > code_max, the values are swapped
 *
 * @param[in,out] code_min  pointer to minimum DAC code (will be clamped/possibly swapped)
 * @param[in,out] code_max  pointer to maximum DAC code (will be clamped/possibly swapped)
 */
static inline void clamp_code_minmax_14(uint16_t *code_min, uint16_t *code_max)
{
    /* Clamp each endpoint to the DAC's 14-bit range */
    if (*code_min > DAC_MAX_14BIT) *code_min = DAC_MAX_14BIT;
    if (*code_max > DAC_MAX_14BIT) *code_max = DAC_MAX_14BIT;

    /* Ensure min <= max (swap if user provided them reversed) */
    if (*code_max < *code_min) {
        uint16_t tmp = *code_min;
        *code_min = *code_max;
        *code_max = tmp;
    }
}

/* ------------------------- Public functions -------------------------- */

/**
 * @brief Fill an output array with a scaled sine wave, packed as 2x14-bit samples per uint32_t.
 *
 * This produces a sine wave with:
 *   - num_cycles cycles across the entire buffer (total_samples)
 *   - output scaled into [code_min, code_max]
 *
 * The sine is computed in floating point:
 *   angle = 2*pi*num_cycles*(sample_index/total_samples)
 *   sin(angle) -> [-1, +1]
 *   normalized = 0.5*(sin + 1) -> [0, 1]
 *   code = code_min + normalized*(code_max-code_min)
 *
 * @param[out] out_array     Destination buffer of uint32_t words
 * @param[in]  array_words   Number of 32-bit words in out_array
 * @param[in]  num_cycles    Number of sine cycles to fit in the whole buffer
 *                           (can be fractional; non-integer cycles will not be periodic at wrap)
 * @param[in]  code_min      Minimum DAC code (clamped to 14-bit)
 * @param[in]  code_max      Maximum DAC code (clamped to 14-bit)
 */
void DAC_14bit_packed_sinewave(uint32_t *out_array,
                                    int array_words,
                                    float num_cycles,
                                    uint16_t code_min,
                                    uint16_t code_max)
{
    /* Packing format uses 2 samples per 32-bit word */
    const int samples_per_word = 2;

    /* Total number of time-domain samples represented by the whole buffer */
    const int total_samples = array_words * samples_per_word;

    /* Validate and correct the user-provided code range */
    clamp_code_minmax_14(&code_min, &code_max);

    /* Span of the waveform (peak-to-peak in DAC codes) */
    const float span = (float)(code_max - code_min);

    for (int i = 0; i < array_words; ++i) {
        /* Map each word index to two consecutive sample indices */
        const int s0 = i * samples_per_word + 0;
        const int s1 = i * samples_per_word + 1;

        /* Compute angles for sample s0 and s1 */
        const float a0 = 2.0f * (float)M_PI * num_cycles * (float)s0 / (float)total_samples;
        const float a1 = 2.0f * (float)M_PI * num_cycles * (float)s1 / (float)total_samples;

        /* Raw sine values in [-1, +1] */
        const float s0f = sinf(a0);
        const float s1f = sinf(a1);

        /* Normalize to [0, 1] so it can be mapped into a code range */
        const float n0 = 0.5f * (s0f + 1.0f);
        const float n1 = 0.5f * (s1f + 1.0f);

        /*
            Scale normalized values into [code_min, code_max].

            The +0.5f provides rounding-to-nearest when casting to uint16_t.
            (Without it, truncation would bias slightly low.)
        */
        const uint16_t v0 = (uint16_t)(code_min + n0 * span + 0.5f);
        const uint16_t v1 = (uint16_t)(code_min + n1 * span + 0.5f);

        /* Pack two 14-bit samples into a 32-bit word */
        out_array[i] =
            ((uint32_t)(v0 & DAC_MASK_14BIT) << 0)  |
            ((uint32_t)(v1 & DAC_MASK_14BIT) << 14);
    }
}

/**
 * @brief Fill an output array with a full-scale triangle wave, packed as 2x14-bit samples per uint32_t.
 *
 * This produces a triangle wave that spans the full DAC range [0..DAC_MAX_14BIT].
 * The triangle is generated by computing a phase p in [0,1), then mapping:
 *   if p < 0.5:  t = 2p          (rising edge)
 *   else:        t = 2(1 - p)    (falling edge)
 * so that t is in [0,1].
 *
 * @param[out] out_array     Destination buffer of uint32_t words
 * @param[in]  array_words   Number of 32-bit words in out_array
 * @param[in]  num_cycles    Number of triangle cycles across the entire buffer
 *                           (fractional cycles allowed; may create discontinuity at wrap)
 */
void DAC_14bit_packed_trianglewave(uint32_t *out_array,
                                        int array_words,
                                        float num_cycles)
{
    const int samples_per_word = 2;
    const int total_samples = array_words * samples_per_word;

    for (int i = 0; i < array_words; ++i) {
        const int s0 = i * samples_per_word + 0;
        const int s1 = i * samples_per_word + 1;

        /*
            Phase calculation:
              (num_cycles * sample_index / total_samples) gives cycles elapsed.
              fmodf(..., 1.0f) keeps only the fractional part -> phase in [0,1).
        */
        const float p0 = fmodf(num_cycles * (float)s0 / (float)total_samples, 1.0f);
        const float p1 = fmodf(num_cycles * (float)s1 / (float)total_samples, 1.0f);

        /* Triangle mapping: produces amplitude t in [0,1] */
        const float t0 = (p0 < 0.5f) ? (2.0f * p0) : (2.0f * (1.0f - p0));
        const float t1 = (p1 < 0.5f) ? (2.0f * p1) : (2.0f * (1.0f - p1));

        /* Scale [0,1] to [0, DAC_MAX_14BIT], with rounding */
        const uint16_t v0 = (uint16_t)(t0 * (float)DAC_MAX_14BIT + 0.5f);
        const uint16_t v1 = (uint16_t)(t1 * (float)DAC_MAX_14BIT + 0.5f);

        /* Pack two 14-bit codes into one 32-bit word */
        out_array[i] =
            ((uint32_t)(v0 & DAC_MASK_14BIT) << 0)  |
            ((uint32_t)(v1 & DAC_MASK_14BIT) << 14);
    }
}

/**
 * @brief Fill an output array with a square wave where each level is held for N samples.
 *
 * Instead of specifying frequency in cycles, this version uses "group_size_samples":
 *   - output stays HIGH for group_size_samples samples
 *   - then stays LOW  for group_size_samples samples
 *   - repeats for the length of the buffer
 *
 * Note: group_size_samples is in *sample units*, not words. Since we pack two
 * samples per word, the grouping can cut across word boundaries naturally.
 *
 * @param[out] out_array          Destination buffer of uint32_t words
 * @param[in]  array_words        Number of 32-bit words in out_array
 * @param[in]  group_size_samples Number of consecutive samples per level (>=1)
 */
void DAC_14bit_grouped_square(uint32_t *out_array,
                                   int array_words,
                                   int group_size_samples)
{
    const int samples_per_word = 2;

    /* Defensive: prevent divide-by-zero / stuck behavior */
    if (group_size_samples <= 0) group_size_samples = 1;

    /* Define the two output levels */
    uint16_t high_value = DAC_MAX_14BIT;
    uint16_t low_value  = 0;

    /* Start HIGH by default */
    uint16_t current    = high_value;

    /* counter counts how many samples we have emitted at the current level */
    int counter = 0;

    for (int i = 0; i < array_words; ++i) {

        /*
            We generate two samples (v0 and v1) per loop iteration, updating the
            (current, counter) state after each emitted sample.
        */

        /* Sample 0 */
        uint16_t v0 = current;
        counter++;
        if (counter >= group_size_samples) {
            counter = 0;
            current = (current == low_value) ? high_value : low_value;
        }

        /* Sample 1 */
        uint16_t v1 = current;
        counter++;
        if (counter >= group_size_samples) {
            counter = 0;
            current = (current == low_value) ? high_value : low_value;
        }

        /* Pack and store */
        out_array[i] =
            ((uint32_t)(v0 & DAC_MASK_14BIT) << 0)  |
            ((uint32_t)(v1 & DAC_MASK_14BIT) << 14);
    }
}

/**
 * @brief Fill an output array with a constant DC code, packed as 2x14-bit samples per uint32_t.
 *
 * This is useful for:
 *   - static DAC output (bias level)
 *   - testing the DAC transfer function
 *   - holding the output between waveform changes
 *
 * @param[out] out_array    Destination buffer of uint32_t words
 * @param[in]  array_words  Number of 32-bit words in out_array
 * @param[in]  dc_value_14b Desired DC code (lower 14 bits used)
 */
void DAC_14bit_packed_dc(uint32_t *out_array,
                              int array_words,
                              uint16_t dc_value_14b)
{
    /* Mask to 14 bits so out-of-range input can't overflow the packing */
    const uint16_t v = (dc_value_14b & DAC_MASK_14BIT);

    /* Pre-pack once, then copy into every word (fast) */
    const uint32_t packed =
        ((uint32_t)v << 0) |
        ((uint32_t)v << 14);

    for (int i = 0; i < array_words; ++i) {
        out_array[i] = packed;
    }
}

/**
 * @brief Fill an output array with a two-tone sine waveform, packed as 2x14-bit samples per uint32_t.
 *
 * Two-tone is commonly used for ADC/DAC dynamic testing (IMD, SFDR, etc.).
 *
 * This function generates:
 *   tone1: cycles1 = base_cycles
 *   tone2: cycles2 = base_cycles + spacing_cycles
 *
 * Both tones are summed and then scaled:
 *   s = 0.5*(sin(tone1) + sin(tone2))
 *
 * The 0.5 factor keeps s roughly in [-1, +1] assuming both sines are in [-1,+1].
 * (Note: worst-case peak of sin(a)+sin(b) is 2, so scaling by 0.5 bounds it to [-1,+1].)
 *
 * Then it is normalized and mapped into [code_min, code_max].
 *
 * @param[out] out_array       Destination buffer of uint32_t words
 * @param[in]  array_words     Number of 32-bit words in out_array
 * @param[in]  base_cycles     Cycles of the first tone across the buffer
 * @param[in]  spacing_cycles  Additional cycles for the second tone (tone2 = base + spacing)
 * @param[in]  code_min        Minimum DAC code (clamped to 14-bit)
 * @param[in]  code_max        Maximum DAC code (clamped to 14-bit)
 */
void DAC_14bit_packed_two_tone(uint32_t *out_array,
                                    int array_words,
                                    float base_cycles,
                                    float spacing_cycles,
                                    uint16_t code_min,
                                    uint16_t code_max)
{
    const int samples_per_word = 2;
    const int total_samples = array_words * samples_per_word;

    /* Ensure scaling range is valid */
    clamp_code_minmax_14(&code_min, &code_max);
    const float span = (float)(code_max - code_min);

    /* Define tone cycle counts across the buffer */
    const float cycles1 = base_cycles;
    const float cycles2 = base_cycles + spacing_cycles;

    for (int i = 0; i < array_words; ++i) {
        const int s0 = i * samples_per_word + 0;
        const int s1 = i * samples_per_word + 1;

        /*
            This inner block explicitly computes sample 0 and sample 1.
            It uses a small amount of variable reuse to keep code compact.
        */

        // sample 0
        {
            float n = (float)s0;

            /* Compute phase angles for both tones at sample index n */
            float a1 = 2.0f * (float)M_PI * cycles1 * n / (float)total_samples;
            float a2 = 2.0f * (float)M_PI * cycles2 * n / (float)total_samples;

            /* Sum tones and scale into [-1, +1] */
            float s = 0.5f * (sinf(a1) + sinf(a2));

            /* Normalize into [0, 1] */
            float v = 0.5f * s + 0.5f;

            /* Map into [code_min, code_max] with rounding */
            uint16_t v0 = (uint16_t)(code_min + v * span + 0.5f);

            // sample 1
            n = (float)s1;
            a1 = 2.0f * (float)M_PI * cycles1 * n / (float)total_samples;
            a2 = 2.0f * (float)M_PI * cycles2 * n / (float)total_samples;
            s = 0.5f * (sinf(a1) + sinf(a2));
            v = 0.5f * s + 0.5f;
            uint16_t v1 = (uint16_t)(code_min + v * span + 0.5f);

            /* Pack the two samples for this word */
            out_array[i] =
                ((uint32_t)(v0 & DAC_MASK_14BIT) << 0)  |
                ((uint32_t)(v1 & DAC_MASK_14BIT) << 14);
        }
    }
}