#ifndef WAVEFORMS_H
#define WAVEFORMS_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

// ---- 14-bit DAC helpers ----
#define DAC_MAX_14BIT   (16383u)
#define DAC_MASK_14BIT  (0x3FFFu)

// Waveform generators (14-bit, packed 2 samples per uint32_t word; lower 24 bits used)
void DAC_14bit_packed_sinewave(uint32_t *out_array,
                                    int array_words,
                                    float num_cycles,
                                    uint16_t code_min,
                                    uint16_t code_max);

void DAC_14bit_packed_trianglewave(uint32_t *out_array,
                                        int array_words,
                                        float num_cycles);

void DAC_14bit_grouped_square(uint32_t *out_array,
                                   int array_words,
                                   int group_size_samples);

void DAC_14bit_packed_dc(uint32_t *out_array,
                              int array_words,
                              uint16_t dc_value_14b);

void DAC_14bit_packed_two_tone(uint32_t *out_array,
                                    int array_words,
                                    float base_cycles,
                                    float spacing_cycles,
                                    uint16_t code_min,
                                    uint16_t code_max);

#ifdef __cplusplus
}
#endif

#endif // WAVEFORMS_H
