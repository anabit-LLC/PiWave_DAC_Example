#ifndef WAVEFORMS_H
#define WAVEFORMS_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

// ---- 12-bit DAC helpers ----
#define DAC_MAX_12BIT   (4095u)
#define DAC_MASK_12BIT  (0x0FFFu)

// Waveform generators (12-bit, packed 2 samples per uint32_t word; lower 24 bits used)
void DAC_12bit_packed_sinewave(uint32_t *out_array,
                                    int array_words,
                                    float num_cycles,
                                    uint16_t code_min,
                                    uint16_t code_max);

void DAC_12bit_packed_trianglewave(uint32_t *out_array,
                                        int array_words,
                                        float num_cycles);

void DAC_12bit_grouped_square(uint32_t *out_array,
                                   int array_words,
                                   int group_size_samples);

void DAC_12bit_packed_dc(uint32_t *out_array,
                              int array_words,
                              uint16_t dc_value_12b);

void DAC_12bit_packed_two_tone(uint32_t *out_array,
                                    int array_words,
                                    float base_cycles,
                                    float spacing_cycles,
                                    uint16_t code_min,
                                    uint16_t code_max);

#ifdef __cplusplus
}
#endif

#endif // WAVEFORMS_H
