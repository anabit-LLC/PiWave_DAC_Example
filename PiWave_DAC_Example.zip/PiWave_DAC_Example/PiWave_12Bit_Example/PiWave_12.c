// ** PiWave_12
//
// This is the top-level application that:
//   1) Initializes the RP2040/RP2350 runtime (stdio + GPIO).
//   2) Builds a wavetable in RAM (wave_buff[]) using helper functions from Waveforms.c/.h.
//   3) Configures a PIO state machine to stream 12-bit parallel DAC samples.
//   4) Configures 2 chained DMA channels (ping-pong) to continuously feed the PIO TX FIFO.
//   5) Starts DMA and then idles forever while the hardware streams the waveform.
//
// The overall idea is:
//   - The waveform samples live in wave_buff[] as 32-bit words.
//   - Each 32-bit word contains TWO packed 12-bit DAC samples:
//       bits [11:0]   = sample 0
//       bits [23:12]  = sample 1
//       bits [31:24]  = unused
//   - PIO pulls 32-bit words from its TX FIFO and outputs the packed samples to GPIO pins
//     connected to the DAC data bus.
//   - DMA moves data from RAM -> PIO TX FIFO at a rate controlled by the PIO DREQ.
//
// Notes:
//   - "PiWave_12.pio.h" is the auto-generated header from your .pio program.
//   - pio_byte_out_program_init() is assumed to set pin directions, clocking, and SM config.
//   - The Z_CTRL_PIN is used to control an output impedance switch (per your note). 
//   - RP2350 datasheet: https://pip-assets.raspberrypi.com/categories/1214-rp2350/documents/RP-008373-DS-2-rp2350-datasheet.pdf?disposition=inline
//
#include <stdio.h>
#include <math.h>

#include "pico/stdlib.h"
#include "hardware/dma.h"
#include "hardware/pio.h"
#include "hardware/clocks.h"
#include "hardware/structs/pio.h"
#include "hardware/structs/dma.h"
#include "PiWave_12.pio.h"
#include "Waveforms.h"  

/* GPIO used to output a copy of the system clock (useful as DAC clock / debug clock) */
#define CLOCK_GPIO 21
/* DMA transfers are 32-bit words (4 bytes). Kept for readability. */
#define BYTES_PER_WORD 4
/* Number of 32-bit words in the waveform buffer */
#define ARRAY_SIZE 256
/* Max 12-bit code */
#define MAX_12BIT 4095
/* GPIO controlling your Z switch:
     0 = 1MΩ
     1 = 50Ω
*/
#define Z_CTRL_PIN 22
#define TERM_50_OHM 1
#define TERM_1_MOHM 0

/* Waveform selection enum-like values */
#define SINE_WAVE     0
#define TRIANGLE_WAVE 1
#define SQUARE_WAVE   2
#define DC_SIGNAL     3
#define TWO_TONE      4
// Select waveform type here:
uint8_t waveType = SQUARE_WAVE;
/*
  wave_buff holds the packed waveform samples.
  The alignment attribute helps in two ways:
    - DMA and bus fabric can be more efficient on aligned buffers
    - (Common practice) makes it easy to use ring settings / wrap boundaries if desired
  Here it's aligned to 1024 bytes.
*/
static uint32_t wave_buff[ARRAY_SIZE] __attribute__((aligned(1024)));

/*
  scaling range for some waveform functions.
  code_min/code_max define the min/max 12-bit DAC codes the waveform will use.
  Note there is an amplifier inverting stage after the DAC so min and max will be swapped
*/
uint16_t code_min = 0;
uint16_t code_max = MAX_12BIT;

int main(void) {
    /* Initialize UART/USB stdio depending on your pico sdk settings */
    stdio_init_all();
    // Initialize Z control GPIO pin
    gpio_init(Z_CTRL_PIN);
    gpio_set_dir(Z_CTRL_PIN, GPIO_OUT);
    // 0 = 1MΩ, 1 = 50Ω
    gpio_put(Z_CTRL_PIN, TERM_50_OHM);
    /*
        First GPIO pin used for the 12-bit parallel DAC bus.
        The PIO program will drive OUT_PIN_NUMBER .. OUT_PIN_NUMBER+NPINS-1.
    */
    uint OUT_PIN_NUMBER = 4;

    /* NPINS is the width of the DAC bus in bits (12-bit DAC => 12 pins) */
    uint8_t NPINS = 12;
    //Desired state machine clock frequency and clock for DAC
    float SM_CLK_FREQ = 150000000;
    //sets up RP2350 clock to output from pin CLOCK_GPIO, this clock signal is used for DAC clocking
    clock_gpio_init(CLOCK_GPIO, CLOCKS_CLK_GPOUT0_CTRL_AUXSRC_VALUE_CLK_SYS,1.0f);
    /*
      Each waveform fill function writes ARRAY_SIZE 32-bit words into wave_buff.
      Remember: 2 samples per word => total_samples = ARRAY_SIZE * 2.

      The "num_cycles" parameters are "cycles across the whole buffer".
      Example: num_cycles = 16 means the buffer contains 16 full waveform periods,
      and then it wraps back to the start when DMA loops.
    */
    switch (waveType) {
        case SINE_WAVE:
            DAC_12bit_packed_sinewave(wave_buff, ARRAY_SIZE, 16.0f, code_min, code_max);
            break;

        case TRIANGLE_WAVE:
            DAC_12bit_packed_trianglewave(wave_buff, ARRAY_SIZE, 8.0f);
            break;

        case SQUARE_WAVE:
            DAC_12bit_grouped_square(wave_buff, ARRAY_SIZE, 16.0);
            break;

        case DC_SIGNAL:
            DAC_12bit_packed_dc(wave_buff, ARRAY_SIZE, 3000);
            break;

        case TWO_TONE:
            DAC_12bit_packed_two_tone(wave_buff, ARRAY_SIZE, 24.0f, 3.0f, code_min, code_max);
            break;

        default:
            /* Fallback waveform if waveType is invalid */
            DAC_12bit_packed_sinewave(wave_buff, ARRAY_SIZE, 16.0f, code_min, code_max);
            break;
    }

    /* ----------------------------------------------------------------------
       Initialize PIO program and state machine
       ---------------------------------------------------------------------- */

    /*
      Select PIO instance and claim an unused state machine.
      - pio0 has 4 state machines (sm 0..3).
      - pio_claim_unused_sm(..., true) will hard-fail if none available.
    */
    PIO pio = pio0;
    uint sm = pio_claim_unused_sm(pio, true);

    /*
      Load the PIO program into instruction memory.
      offset is the start index of this program in the PIO instruction RAM.
    */
    uint offset = pio_add_program(pio, &pio_byte_out_program);

    /*
      Initialize the program:
        - configure pins (OUT pin base, pin count)
        - set clock divider to achieve SM_CLK_FREQ
        - configure shift/out settings as required by your .pio code
      The details live in the generated init function from PiWave.pio.
    */
    pio_byte_out_program_init(pio, sm, offset, OUT_PIN_NUMBER, NPINS, SM_CLK_FREQ);

    /* ----------------------------------------------------------------------
       DMA configuration (two-channel chained "ping-pong")
       ---------------------------------------------------------------------- */

    /*
      This design uses two DMA channels that chain to each other so the
      waveform repeats forever:

        DMA A transfers wave_buff -> PIO TX FIFO, then chains to DMA B.
        DMA B transfers wave_buff -> PIO TX FIFO, then chains back to DMA A.

      This creates continuous playback without CPU intervention.

      Note:
        - read_increment = true  : walk through wave_buff[]
        - write_increment = false: always write to the same FIFO address
        - DREQ_PIO0_TX0 throttles DMA so it only writes when the PIO TX FIFO
          can accept data (prevents FIFO overflow).
    */

    /* Claim two unused DMA channels */
    int dma_chan_a = dma_claim_unused_channel(true);
    int dma_chan_b = dma_claim_unused_channel(true);

    /* --- DMA Channel A config --- */
    dma_channel_config wave_dma_chan_a_config = dma_channel_get_default_config(dma_chan_a);

    /* Transfer 32-bit words (matches wave_buff element type and PIO FIFO width) */
    channel_config_set_transfer_data_size(&wave_dma_chan_a_config, DMA_SIZE_32);

    /* Read from sequential addresses in wave_buff */
    channel_config_set_read_increment(&wave_dma_chan_a_config, true);

    /* Write always to the same destination (PIO TX FIFO register) */
    channel_config_set_write_increment(&wave_dma_chan_a_config, false);

    /* When channel A completes, automatically start channel B */
    channel_config_set_chain_to(&wave_dma_chan_a_config, dma_chan_b);

    /*
      DREQ selects the pacing signal.
      DREQ_PIO0_TX0 means: "only perform a DMA write when PIO0 SM0 TX FIFO needs data".

      WARNING:
        This constant is SM-specific in many SDK setups.
        If sm != 0, you may need DREQ_PIO0_TX0 + sm (depending on SDK definitions).
        As written, this assumes either:
          - sm == 0, or
          - your PIO init uses SM0, or
          - the PIO program / DREQ constant is otherwise correct in your environment.
    */
    channel_config_set_dreq(&wave_dma_chan_a_config, DREQ_PIO0_TX0);

    /*
      Ring (wrap) configuration:
        channel_config_set_ring(&cfg, write, size_bits)

      With write=false, this applies to READ address wrapping.

      size_bits=8 means the read address wraps on a 2^8 = 256 byte boundary.
      Since wave_buff is 256 words * 4 bytes/word = 1024 bytes, wrapping at 256 bytes
      would only cover 64 words, NOT the full buffer.

      However, in this program the channel is configured with a fixed transfer count
      (ARRAY_SIZE), and then restarted by chaining. So the ring setting is not required
      for looping the buffer and could be a leftover from an earlier ring-buffer experiment.

      If you want ring wrapping to cover the entire wave_buff (1024 bytes),
      you would use size_bits=10 (2^10=1024), and ensure alignment to 1024 bytes.
    */
    channel_config_set_ring(&wave_dma_chan_a_config, false, 8);

    /* --- DMA Channel B config (mirrors channel A) --- */
    dma_channel_config wave_dma_chan_b_config = dma_channel_get_default_config(dma_chan_b);
    channel_config_set_transfer_data_size(&wave_dma_chan_b_config, DMA_SIZE_32);
    channel_config_set_read_increment(&wave_dma_chan_b_config, true);
    channel_config_set_write_increment(&wave_dma_chan_b_config, false);

    /* When channel B completes, automatically start channel A */
    channel_config_set_chain_to(&wave_dma_chan_b_config, dma_chan_a);

    /* Same pacing signal as channel A */
    channel_config_set_dreq(&wave_dma_chan_b_config, DREQ_PIO0_TX0);

    /* Same ring setting caveat as above */
    channel_config_set_ring(&wave_dma_chan_b_config, false, 8);

    /* ----------------------------------------------------------------------
       Program the DMA channels
       ---------------------------------------------------------------------- */

    /*
      Configure channel A:
        - dst: PIO TX FIFO for the chosen state machine
        - src: wave_buff (wavetable in RAM)
        - transfer_count: ARRAY_SIZE words
        - start_immediately: false (we start it explicitly later)
    */
    dma_channel_configure(
        dma_chan_a,
        &wave_dma_chan_a_config,
        &pio0_hw->txf[sm],   /* destination address: TX FIFO register */
        wave_buff,            /* source address: wavetable */
        ARRAY_SIZE,          /* number of 32-bit words */
        false
    );

    /* Configure channel B identically */
    dma_channel_configure(
        dma_chan_b,
        &wave_dma_chan_b_config,
        &pio0_hw->txf[sm],
        wave_buff,
        ARRAY_SIZE,
        false
    );

    /* Start playback by starting channel A; it will chain to B, then back to A, etc. */
    dma_start_channel_mask(1u << dma_chan_a);

    /* ----------------------------------------------------------------------
       Main loop
       ---------------------------------------------------------------------- */

    /*
      Once DMA + PIO are running, the CPU can do other tasks:
        - respond to USB/UART commands
        - refill wave_buff for dynamic waveforms (careful with DMA coherence)
        - update waveType, code_min/max, etc.
        - measure or log debug info
      For now, we just sleep forever.
    */
    while (1) {
        sleep_ms(1000);
    }

    return 0;
}
